# Red Flags
⚠️ Missing targets consistently  
⚠️ High executive turnover  
⚠️ Board relationship strained  
⚠️ Culture deteriorating  
⚠️ Market share declining  
⚠️ Cash burn increasing  
⚠️ Innovation stalling  
⚠️ Personal burnout signs
