# Launch Brief

- Goals & success criteria
- Positioning & narrative
- Proof points & references
- Risks & mitigations
- Timeline & owners
