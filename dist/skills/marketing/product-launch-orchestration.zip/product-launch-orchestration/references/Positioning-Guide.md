# Positioning Guide

Use Strategic Research Toolkit to inform:
- Market Research
- Competitive Intelligence
- Customer Discovery

Craft messaging from insights.
