# Launch Content Pack Checklist

- Blog post
- Landing page
- Email sequence
- Social promo set
- Ad creative
- Measurement plan
