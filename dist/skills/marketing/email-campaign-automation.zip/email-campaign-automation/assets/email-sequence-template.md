# Email Sequence Template (3-Part)

## Email 1: Welcome
Subject: Welcome to [Brand]! Here’s your [Value]

## Email 2: Proof
Subject: How [Customer] achieved [Outcome]

## Email 3: Next Step
Subject: Ready to [Outcome]? Here’s your next step
