# Newsletter Template

Title: [Topic]
Intro: Brief hook

Sections:
- Insight 1
- Insight 2
- Insight 3

CTA: Read full article / Watch video / Download
