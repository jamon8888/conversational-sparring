# Email Sequence Patterns

- Welcome (3 parts): intro, value, next step
- Nurture (5 parts): educate, case study, objection, proof, CTA
- Promo (3 parts): offer, urgency, close
- Reactivation (3 parts): check-in, value, survey/offer
