# Executive Summary Template

- Highlights (MoM/YoY)
- Top Content and Campaigns
- Key Wins / Issues / Actions
