# Unified Analytics Dashboard Template

Sections
- Executive KPIs
- Top Performing Content
- Channel Trends (MoM)
- Optimal Timing Windows
- Topic Opportunities

Use Data Studio/Sheets and feed CSVs produced by scripts.
