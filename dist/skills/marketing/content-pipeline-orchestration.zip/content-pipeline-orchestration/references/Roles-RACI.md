# Roles & RACI

- Content Lead: A/R
- Writer: R
- Editor: R
- Designer: R
- Social Manager: R
- Analyst: R
