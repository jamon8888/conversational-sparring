# Pipeline SOP

Stages: Ideation → Creation → Review → Repurpose → Schedule → Distribute → Measure
Quality gates: SEO score, structure, tone, internal links
SLAs: define per stage
