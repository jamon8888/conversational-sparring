# LinkedIn Post Template

## Hook (First 2 lines)
[Attention-grabbing statement or question]
[Build curiosity]

## Context
[Why this matters]
[Personal connection or data point]

## Main Content
[Key insight 1]

[Key insight 2]

[Key insight 3]

## Takeaways
Key takeaways:

→ [Takeaway 1]
→ [Takeaway 2]
→ [Takeaway 3]

## CTA
---

What's your experience with [topic]?

💬 Share in the comments
🔄 Repost to help others
👍 Like if this resonates

#hashtag1 #hashtag2 #hashtag3
