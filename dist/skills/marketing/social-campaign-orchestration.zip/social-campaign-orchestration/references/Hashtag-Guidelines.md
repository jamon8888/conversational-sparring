# Hashtag Guidelines

- Twitter: 1–2
- LinkedIn: 3–5
- Instagram: 5–10 (max 30)
- YouTube: 3–5
