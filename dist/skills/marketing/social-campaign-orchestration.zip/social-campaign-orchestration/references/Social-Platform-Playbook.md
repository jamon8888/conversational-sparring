# Social Platform Playbook

Twitter: 280 chars, 1–2 hashtags, threads for depth
LinkedIn: 1200–1500 chars, line breaks, expertise tone
Instagram: 138–150 char hooks, 5–10 hashtags, carousels
YouTube: 200–300 char description, timestamps/chapters
