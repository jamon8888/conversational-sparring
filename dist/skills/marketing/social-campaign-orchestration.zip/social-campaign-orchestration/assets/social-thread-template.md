# Social Thread Template

1) Hook
2) Key point
3) Key point
4) CTA
