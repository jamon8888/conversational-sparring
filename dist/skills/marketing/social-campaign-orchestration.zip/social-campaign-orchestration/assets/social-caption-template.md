# Social Caption Template

Hook: [Question/Insight]
Bullets: [1–3 takeaways]
Hashtags: #[tag1] #[tag2] #[tag3]
