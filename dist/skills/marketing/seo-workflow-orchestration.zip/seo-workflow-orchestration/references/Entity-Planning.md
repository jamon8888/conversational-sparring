# Entity Planning Guide

1. Identify primary entities (product, problem, ICP)
2. Collect related entities (brands, standards, competitors, tools)
3. Build a glossary: term, short definition, relationships
4. Map entities into H2/H3s where natural
5. Cross-link related sections and supporting articles
