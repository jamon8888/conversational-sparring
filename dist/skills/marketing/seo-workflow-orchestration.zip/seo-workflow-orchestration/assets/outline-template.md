# Outline Template (Pillar)

## H1: Primary Topic
Intro paragraph. Include TL;DR.

## H2: Core Concept 1
...

## H2: Core Concept 2
...

## Q&A
Q: ...
A: ...

## Sources
- [Source Title](url) – Date

Last updated: YYYY-MM-DD | Author: Name, Title
