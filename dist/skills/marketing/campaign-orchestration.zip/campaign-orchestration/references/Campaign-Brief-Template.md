# Campaign Brief

- Objective
- ICP/Persona
- Offer/CTA
- Channels
- Timeline
- KPIs
